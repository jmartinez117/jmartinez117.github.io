# NixOS Desktop — Portfolio (Single File)

- Login splash (no real auth, privacy-safe)
- Dock + draggable windows (About, Resume, Projects, Terminal, Mousepad, Settings, Contact)
- **Mexico City clock** (IANA tz: America/Mexico_City)
- **CSP** with SHA-256 hash for the inline script; no external scripts; no trackers
- **Verbatim resume** included in `Resume` window and `resume.pdf`

## Deploy on GitHub Pages
1) Create a **public** repo named `yourusername.github.io`.
2) Upload `index.html`, `resume.pdf`, and `.nojekyll` to the repo root.
3) **Settings → Pages** → Source: `Deploy from a branch` → Branch: `main` → Folder: `/`.
4) Visit `https://yourusername.github.io` (replace username).

## Customize
- Form endpoint in Contact window: replace `https://formspree.io/f/your-id` with your Formspree URL.
- Theme: open Settings and toggle the accent color.
- Projects: edit links inside the Projects window.